package com.example.stock_market;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;

public class AboutMeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about_me_fragment);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.example_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.item1:
                Log.i("Menu", "Item 1");
                Intent i = new Intent(AboutMeActivity.this, RecyclerActivity.class);
                startActivity(i);
                return true;
            case R.id.item2:
                Log.i("Menu", "Item 2");
                Intent ix = new Intent(AboutMeActivity.this, AboutMeActivity.class);
                startActivity(ix);
                return true;
            case R.id.item3:
                Log.i("Menu", "Item 3");
                Intent iz = new Intent(AboutMeActivity.this, MapsActivity.class);
                startActivity(iz);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
