package com.example.stock_market;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //RecyclerActivity Arrays
    public static String mTitle[] = new String[20];
    public static String mDescription[] = new String[20];
    public static String mImages[] = new String[20];
    public static String mUrl[] = new String[20];

    DatabaseRegisterHelper database;
    EditText TextEmail;
    EditText TextPassword;
    Button ButtonLogin;
    Button ButtonRegister;

     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         database = new DatabaseRegisterHelper(this);
         TextEmail = findViewById(R.id.emailTextLogin);
         TextPassword = findViewById(R.id.passwordTextLogin);
         ButtonLogin = findViewById(R.id.loginButtonLogin);
         ButtonRegister =  findViewById(R.id.signupButtonSignup);



         ButtonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = TextEmail.getText().toString().trim();
                String pwd = TextPassword.getText().toString().trim();
                Boolean res = database.checkLogin(user, pwd);
                if(res == true)
                {
                    Intent HomePage = new Intent(MainActivity.this,RecyclerActivity.class);
                    startActivity(HomePage);
                } else
                {
                    Toast.makeText(MainActivity.this,"Login Error",Toast.LENGTH_SHORT).show();
                }
            }
        });

         ButtonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, SignUpActivity.class);
                startActivity(i);
            }
        });


            SQLiteDatabase myDatabase = this.openOrCreateDatabase("Database.list", MODE_PRIVATE, null);

            /* Create a Table in the Database. */
            myDatabase.execSQL("CREATE TABLE IF NOT EXISTS stocks (id INT NOT NULL, company_C VARCHAR(255), company_L VARCHAR(255),code VARCHAR(255),url VARCHAR(255))");

            /* Insert data to a Table*/
            myDatabase.execSQL("INSERT INTO 'stocks' (`id`, `company_C`, `company_L`, `code`, `url`) VALUES (0, 'Disney', 'disney', 'DIS', 'https://uk.tradingview.com/symbols/NYSE-DIS/')");
            myDatabase.execSQL("INSERT INTO 'stocks' (`id`, `company_C`, `company_L`, `code`, `url`) VALUES (1, 'Netflix', 'netflix','NFLX','https://uk.tradingview.com/symbols/NASDAQ-NFLX/')");
            myDatabase.execSQL("INSERT INTO 'stocks' (`id`, `company_C`, `company_L`, `code`, `url`) VALUES (2, 'Sony', 'sony','SNE','https://uk.tradingview.com/symbols/TSE-6758/')");
            myDatabase.execSQL("INSERT INTO 'stocks' (`id`, `company_C`, `company_L`, `code`, `url`) VALUES (3, 'Amazon', 'amazon','AMZN','https://uk.tradingview.com/symbols/NASDAQ-AMZN/')");
            myDatabase.execSQL("INSERT INTO 'stocks' (`id`, `company_C`, `company_L`, `code`, `url`) VALUES (4, 'Google', 'google','GOOG','https://uk.tradingview.com/symbols/NASDAQ-GOOG/')");
            myDatabase.execSQL("INSERT INTO 'stocks' (`id`, `company_C`, `company_L`, `code`, `url`) VALUES (5, 'Microsoft', 'microsoft','MSFT','https://uk.tradingview.com/symbols/NASDAQ-MSFT/')");
            myDatabase.execSQL("INSERT INTO 'stocks' (`id`, `company_C`, `company_L`, `code`, `url`) VALUES (6, 'IBM', 'ibm','IBM','https://uk.tradingview.com/symbols/NYSE-IBM/')");
            myDatabase.execSQL("INSERT INTO 'stocks' (`id`, `company_C`, `company_L`, `code`, `url`) VALUES (7, 'Apple', 'apple','AAPL','https://uk.tradingview.com/symbols/NASDAQ-AAPL/')");
            myDatabase.execSQL("INSERT INTO 'stocks' (`id`, `company_C`, `company_L`, `code`, `url`) VALUES (8, 'Intel', 'intel','INTC','https://uk.tradingview.com/symbols/NASDAQ-INTC/')");
            myDatabase.execSQL("INSERT INTO 'stocks' (`id`, `company_C`, `company_L`, `code`, `url`) VALUES (9, 'Autodesk', 'autodesk', 'ADSK', 'https://uk.tradingview.com/symbols/NASDAQ-ADSK/')");
            myDatabase.execSQL("INSERT INTO 'stocks' (`id`, `company_C`, `company_L`, `code`, `url`) VALUES (10, 'AT&T', 'att','T','https://uk.tradingview.com/symbols/NYSE-T/')");
            myDatabase.execSQL("INSERT INTO 'stocks' (`id`, `company_C`, `company_L`, `code`, `url`) VALUES (11,'Tesla', 'tesla','TSLA','https://uk.tradingview.com/symbols/NASDAQ-TSLA/')");
            myDatabase.execSQL("INSERT INTO 'stocks' (`id`, `company_C`, `company_L`, `code`, `url`) VALUES (12, 'Coca Cola', 'coca_cola','KO','https://uk.tradingview.com/symbols/NYSE-KO/')");
            myDatabase.execSQL("INSERT INTO 'stocks' (`id`, `company_C`, `company_L`, `code`, `url`) VALUES (13, 'McDonalds', 'mcdonalds','MCD','https://uk.tradingview.com/symbols/NYSE-MCD/')");
            myDatabase.execSQL("INSERT INTO 'stocks' (`id`, `company_C`, `company_L`, `code`, `url`) VALUES (14, 'Ebay', 'ebay','EBAY','https://uk.tradingview.com/symbols/NASDAQ-EBAY/')");
            myDatabase.execSQL("INSERT INTO 'stocks' (`id`, `company_C`, `company_L`, `code`, `url`) VALUES (15, 'Facebook', 'facebook','FB','https://uk.tradingview.com/symbols/NASDAQ-FB/')");
            myDatabase.execSQL("INSERT INTO 'stocks' (`id`, `company_C`, `company_L`, `code`, `url`) VALUES (16, 'American Airlines', 'american_airlines','AAL','https://uk.tradingview.com/symbols/NASDAQ-AAL/')");
            myDatabase.execSQL("INSERT INTO 'stocks' (`id`, `company_C`, `company_L`, `code`, `url`) VALUES (17, 'Nike', 'nike','MKE','https://uk.tradingview.com/symbols/NYSE-NKE/')");
            myDatabase.execSQL("INSERT INTO 'stocks' (`id`, `company_C`, `company_L`, `code`, `url`) VALUES (18, 'Bitcoin', 'bitcoin','BTC','https://uk.tradingview.com/symbols/BTCGBP/?exchange=COINBASE')");
            myDatabase.execSQL("INSERT INTO 'stocks' (`id`, `company_C`, `company_L`, `code`, `url`) VALUES (19, 'Oracle', 'oracle','ORCL','https://uk.tradingview.com/symbols/NYSE-ORCL/')");

            /*retrieve data from database */
            Cursor c = myDatabase.rawQuery("SELECT * FROM stocks", null);

            int indexTitle = c.getColumnIndex("company_C");
            int indexImage = c.getColumnIndex("company_L");
            int indexCode = c.getColumnIndex("code");
            int indexUrl = c.getColumnIndex("url");
         try {
            // Check if our result was valid.
            c.moveToFirst();
            if (c != null) {
                // Loop through all Results
                int i = 0;
                do {
                    Log.i("test", c.getString(indexTitle));
                    Log.i("test", c.getString(indexImage));
                    Log.i("test", c.getString(indexCode));
                    Log.i("test", c.getString(indexUrl));

                    mTitle[i] = c.getString(indexTitle);
                    mImages[i] = c.getString(indexImage);
                    mDescription[i] = c.getString(indexCode);
                    mUrl[i] = c.getString(indexUrl);
                    i++;
                } while (c.moveToNext());
            }
        }catch(Exception e){
            Log.i("Expection", "ERROR");
        }
    }
    public static String[] getmTitle(){ return mTitle; }
    public String[] getmImages(){ return mImages; }
    public static String[] getmDescription(){ return mDescription; }
    public static String[] getmUrl(){ return mUrl; }

}
