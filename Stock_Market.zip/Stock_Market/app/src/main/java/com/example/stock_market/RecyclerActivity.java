package com.example.stock_market;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class RecyclerActivity extends AppCompatActivity {

    ListView recyclerView;
    String mTitle[] = MainActivity.getmTitle();
    String mDescription[] = MainActivity.getmDescription();
    String mUrl[] = MainActivity.getmUrl();
    int images[] = {R.drawable.disney, R.drawable.netflix, R.drawable.sony, R.drawable.amazon, R.drawable.google, R.drawable.microsoft, R.drawable.ibm, R.drawable.apple, R.drawable.intel, R.drawable.autodesk,
            R.drawable.att, R.drawable.tesla, R.drawable.coca_cola, R.drawable.mcdonals, R.drawable.ebay, R.drawable.facebook, R.drawable.american_airlines, R.drawable.nike, R.drawable.bitcoin, R.drawable.oracle};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler);

        recyclerView = findViewById(R.id.recyclerView);

        MyAdapter adapter = new MyAdapter(this, mTitle, mDescription, images);
        recyclerView.setAdapter(adapter);

        recyclerView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                for(int i = 0; i < position; i++){
                    Toast.makeText( RecyclerActivity.this, "Opening " + mTitle[position], Toast.LENGTH_SHORT).show();
                }
                Intent intent = new Intent(RecyclerActivity.this, WebActivity.class);
                String url = mUrl[position];
                Log.i("RecyclerVIEW", url);
                intent.putExtra("url", url);
                startActivity(intent);
                Intent intent2 = new Intent(RecyclerActivity.this, WebActivity.class);
                startActivity(intent2);
            }
        });

    }


    class MyAdapter extends ArrayAdapter<String> {

        Context context;
        String rTitle[];
        String rDescription[];
        int rImgs[];

        MyAdapter(Context c, String title[], String description[], int imgs[]){
            super(c, R.layout.row, R.id.textView1, title);
            this.context = c;
            this.rTitle = title;
            this.rDescription = description;
            this.rImgs = imgs;

        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater = (LayoutInflater)getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row = layoutInflater.inflate(R.layout.row, parent, false);
            ImageView images = row.findViewById(R.id.image);
            TextView myTitle = row.findViewById(R.id.textView1);
            TextView myDescription = row.findViewById(R.id.textView2);

            images.setImageResource(rImgs[position]);
            myTitle.setText(rTitle[position]);
            myDescription.setText(rDescription[position]);

            return row;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.example_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.item1:
            Log.i("Menu", "Item 1");
                Intent i = new Intent(RecyclerActivity.this, RecyclerActivity.class);
                startActivity(i);
            return true;
            case R.id.item2:
                Log.i("Menu", "Item 2");
                Intent ix = new Intent(RecyclerActivity.this, AboutMeActivity.class);
                startActivity(ix);
                return true;
            case R.id.item3:
                Log.i("Menu", "Item 3");
                Intent iz = new Intent(RecyclerActivity.this, MapsActivity.class);
                startActivity(iz);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
