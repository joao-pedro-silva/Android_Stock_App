package com.example.stock_market;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignUpActivity extends AppCompatActivity {

    DatabaseRegisterHelper db;
    EditText TextEmail;
    EditText TextPassword;
    EditText TextPassword2;
    Button ButtonRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        db = new DatabaseRegisterHelper(this);
        TextEmail = findViewById(R.id.emailSignUp);
        TextPassword = findViewById(R.id.passwordSignUp);
        TextPassword2 = findViewById(R.id.passwordSignUp2);
        ButtonRegister = findViewById(R.id.signupButtonSignup);

        ButtonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = TextEmail.getText().toString().trim();
                String pwd = TextPassword.getText().toString().trim();
                String cnf_pwd = TextPassword2.getText().toString().trim();

                if (pwd.equals("") || user.equals("")) { //No Empty User or Password
                    Toast.makeText(SignUpActivity.this, "Non exiting User or Password", Toast.LENGTH_SHORT).show();
                }
                else if (pwd.equals(cnf_pwd)) {
                        long x = db.checkSign(user, pwd);
                        if (x > 0) {
                            Toast.makeText(SignUpActivity.this, "You have registered", Toast.LENGTH_SHORT).show();
                            Intent moveToLogin = new Intent(SignUpActivity.this, MainActivity.class);
                            startActivity(moveToLogin);
                        } else {
                            Log.i("SignUp", "Registration Error");
                            Toast.makeText(SignUpActivity.this, "Registration Error", Toast.LENGTH_SHORT).show();
                        }
                } else {Toast.makeText(SignUpActivity.this, "Password is not matching", Toast.LENGTH_SHORT).show();}

            }
        });
    }

}
