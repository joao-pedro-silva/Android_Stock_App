package com.example.stock_market;

import org.junit.Test;

import static com.example.stock_market.MainActivity.getmDescription;
import static com.example.stock_market.MainActivity.getmTitle;
import static com.example.stock_market.MainActivity.getmUrl;
import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class MainActivityUnitTest {
    @Test
    public void addition_isCorrect() {

        assertTrue(getmTitle() != null);
        assertTrue(getmDescription() != null);
        assertTrue(getmUrl() != null);
    }
}